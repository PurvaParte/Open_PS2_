from pydantic import BaseModel

class EventCreate(BaseModel):
    session_id:int
    timestamp:int
    event_type:str
    data:str
