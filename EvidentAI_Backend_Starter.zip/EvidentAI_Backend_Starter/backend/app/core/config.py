import os


class Settings:
    PROJECT_NAME: str = "EvidentAI - Session Replay & Integrity Engine"
    VERSION: str = "1.0.0"
    API_PREFIX: str = "/api"

    # Integrity Analyzer Rule Thresholds
    LARGE_PASTE_CHAR_THRESHOLD: int = int(os.getenv("LARGE_PASTE_CHAR_THRESHOLD", "50"))
    LARGE_PASTE_HIGH_SEVERITY_CHARS: int = int(os.getenv("LARGE_PASTE_HIGH_SEVERITY_CHARS", "150"))

    RAPID_INSERT_CHAR_THRESHOLD: int = int(os.getenv("RAPID_INSERT_CHAR_THRESHOLD", "200"))
    RAPID_INSERT_WINDOW_MS: int = int(os.getenv("RAPID_INSERT_WINDOW_MS", "2000"))

    LOW_EDIT_MAX_DELETES: int = int(os.getenv("LOW_EDIT_MAX_DELETES", "2"))
    LOW_EDIT_MIN_PASTED_CHARS: int = int(os.getenv("LOW_EDIT_MIN_PASTED_CHARS", "30"))

    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./evidentai.db")


settings = Settings()