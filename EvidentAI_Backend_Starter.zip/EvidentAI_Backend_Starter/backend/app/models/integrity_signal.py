from sqlalchemy import Column, Integer, String, ForeignKey, Text
from sqlalchemy.orm import relationship
from app.database.database import Base

class IntegritySignal(Base):
    __tablename__="integrity_signals"
    id=Column(Integer, primary_key=True, index=True)
    session_id=Column(Integer, ForeignKey("sessions.id"))
    rule_name=Column(String)
    severity=Column(String)
    event_id=Column(Integer)
    timestamp=Column(Integer)
    reason=Column(Text)
    session=relationship("Session", back_populates="signals")
