from sqlalchemy import Column, Integer, String, ForeignKey, Text
from sqlalchemy.orm import relationship
from app.database.database import Base

class Event(Base):
    __tablename__="events"
    id=Column(Integer, primary_key=True, index=True)
    session_id=Column(Integer, ForeignKey("sessions.id"))
    timestamp=Column(Integer)
    event_type=Column(String)
    data=Column(Text)
    session=relationship("Session", back_populates="events")
