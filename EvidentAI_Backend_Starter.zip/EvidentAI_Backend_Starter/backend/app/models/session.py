from sqlalchemy import Column, Integer, String
from sqlalchemy.orm import relationship
from app.database.database import Base

class Session(Base):
    __tablename__="sessions"
    id=Column(Integer, primary_key=True, index=True)
    student_id=Column(String, nullable=False)
    started_at=Column(String)
    ended_at=Column(String)
    events=relationship("Event", back_populates="session")
    signals=relationship("IntegritySignal", back_populates="session")
