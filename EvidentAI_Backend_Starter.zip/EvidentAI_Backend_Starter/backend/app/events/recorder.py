from sqlalchemy.orm import Session
from app.models import Event

def record_event(db: Session, session_id:int, timestamp:int, event_type:str, data:str):
    event=Event(session_id=session_id,timestamp=timestamp,event_type=event_type,data=data)
    db.add(event)
    db.commit()
    db.refresh(event)
    return event
