def analyze_session(events):
    signals=[]
    for event in events:
        if event.event_type=="paste" and len(event.data)>150:
            signals.append({"rule":"Large Paste","event_id":event.id,"timestamp":event.timestamp,"reason":"Large pasted content detected."})

    previous=None
    for event in events:
        if previous and event.timestamp-previous.timestamp<200 and len(event.data)>100:
            signals.append({"rule":"Rapid Insertion","event_id":event.id,"timestamp":event.timestamp,"reason":"Large amount of code appeared unusually fast."})
        previous=event

    runs=0
    edits=0
    for event in events:
        if event.event_type=="run":
            runs+=1
        if event.event_type in ["insert","delete","paste"]:
            edits+=1
    if runs>0 and edits<runs:
        signals.append({"rule":"Low Edit Cycle","event_id":None,"timestamp":None,"reason":"Many runs with very little editing observed."})
    return signals
