from sqlalchemy.orm import Session
from app.models import Event

def get_session_events(db: Session, session_id:int):
    return db.query(Event).filter(Event.session_id==session_id).order_by(Event.timestamp).all()
